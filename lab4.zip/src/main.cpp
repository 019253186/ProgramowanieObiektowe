#include <iostream>
#include "../inc/menu.h"

using namespace std;

int main(){
    Tablica tab;
    while(run(tab));
    return 0;
}
#include <bits/stdc++.h>
#include "tablica.h"
using namespace std;

void showMenu();
bool run(Tablica& tab);
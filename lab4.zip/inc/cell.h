#include <bits/stdc++.h>
using namespace std;

class Cell{
    T value;
};